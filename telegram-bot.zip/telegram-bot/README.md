# Telegram Auto-Approve Bot

Bot que aprueba automáticamente solicitudes de unión a un canal privado de Telegram cada 60 segundos.

## Despliegue en Railway

1. Sube esta carpeta a un repositorio de GitHub
2. Ve a railway.app y crea una cuenta
3. New Project → Deploy from GitHub repo
4. Selecciona el repositorio
5. Railway detecta el Procfile automáticamente
6. Deploy — listo

## Archivos

- `main.py` — script principal
- `requirements.txt` — dependencias
- `Procfile` — instrucciones para Railway
